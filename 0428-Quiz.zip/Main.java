import java.util.Scanner;
import java.util.Random;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    Random rand = new Random();

    //6-16
    // String[] arrENG = {"monday", "tuesday", "wendsday", "thursday", "friday", "saterday", "sunday"};
    // String[] arrKO = {"월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"} ;

    // int re = -1;
    // int retry = 0;
    // System.out.println("요일명을 영어 소문자로 입력하시요.");
    // do {
    //   int days;
    //   do {
    //     days = rand.nextInt(7);
    //   } while(days == re);
    //   re = days;

    //   while (true) {
    //     System.out.print(arrKO[days] + ": " );
    //     String s = sc.next();

    //     if(s.equals(arrENG[days])) break;

    //     System.out.println("틀렸습니다.");
    //   }
    //   System.out.println("정답입니다.");
    //   System.out.print("다시 한번? 1...Yes/0... No:0");
    //   retry = sc.nextInt();
    // }while(retry == 1);


    //6-18
    // int[][] a = new int[4][3];
    // int[][] b = new int[3][4];
    // int[][] c = new int[4][4];

    // System.out.println("행렬 a의 요소를 입력하세요");

    // for (int i = 0; i < 4; i++) {
    //   for(int j = 0; j < 3; j++) {
    //     System.out.print("a[" + i + "][" + j+ "]: ");
    //     a[i][j] = sc.nextInt();

    //   }
    // }

    // System.out.println("행렬 b의 요소를 입력하세요");
    // for (int i = 0; i < 3; i++) {
    //   for(int j = 0; j < 4; j++) {
    //     System.out.print("b[" + i + "][" + j+ "]: ");
    //     b[i][j] = sc.nextInt();
    //   }
    // }
    // System.out.println("행렬 a와 b의 곱");

    // for(int i = 0 ; i < 4;i++) {
    //   for(int j = 0; j < 4;j++) {
    //     c[i][j] = 0;
    //     for(int k = 0; k <3; k++){
    //       c[i][j] += a[i][k]*b[k][j];
    //     }
    //   }
    // } 
    
    // for(int i = 0 ; i < 4;i++) {
    //   for(int j = 0; j < 4;j++) {
    //     System.out.print(c[i][j] + " ");
    //   }
    //   System.out.println();
    // } 
    
    
    //6-19
    // System.out.println("6명의 국어, 수학 점수를 입력하세요.");
    // int[][] point = new int[6][2];
    // int[] sumStudent = new int[6];
    // int[] sumSubject = new int[2];

    // for (int i = 0; i < 6; i++) {
    //   System.out.print((i+1) + "번 국어 :" );
    //   point[i][0] = sc.nextInt();
    //   System.out.print("    수학 :" );
    //   point[i][1] = sc.nextInt();

    //   sumStudent[i] = point[i][0] + point[i][1];
    //   sumSubject[0] += point[i][0];
    //   sumSubject[1] += point[i][1];
    // }
    // System.out.println("NO.\t 국어 \t 수학 \t 평균");
    // for(int i = 0; i < 6; i++) {
    //   System.out.print((i+1) + "\t" + point[i][0] + "\t\t" + point[i][0] + "\t\t" + ((double)sumStudent[i]/2));
    //   System.out.println();
    // }
    // System.out.println("평균" + "\t" + ((double)sumSubject[0]/6) + "\t" + ((double)sumSubject[1]/6));

    //6-21
        System.out.print("학급수 : ");
    int classNum = sc.nextInt();
    int[][] point = new int[classNum][];
    int totNumber = 0;

  for (int i = 0 ; i < point.length ; i ++){
    System.out.print((i+1)+"반의 학생수 : ");
    int num = sc.nextInt();

    point[i] = new int[num];
    totNumber += num;

    for (int j = 0; j < point[i].length; j++){
      System.out.print((i+1) + "반"+ (j+1) +"번의 점수 :");
      point[i][j] = sc.nextInt();
    }
  }
    System.out.println(" 반 | 합계    평균");
    System.out.println("----+-------------");
    int total = 0;
    for (int i = 0 ; i < point.length; i++) {
      int sum = 0;
      for (int j = 0; j <point[i].length; j++) {
        sum += point[i][j];
      total += sum;
      }
    System.out.printf("%2d반 | %8d  %8.1f", i+1, sum, (double)sum/point[i].length);
    System.out.println();
  }
  System.out.println("----+-------------");
  System.out.println(" 합 | "+ total + ((double)total / totNumber));  

  }
}
