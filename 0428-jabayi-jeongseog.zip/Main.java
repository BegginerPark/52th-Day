import java.util.*;
import java.util.regex.*;

class Main {
  public static void main(String[] args) {
    //9-27
    // Random rand = new Random();
    // Random rand2 = new Random();

    // System.out.println("= rand =");
    // for (int i = 0; i < 5; i++) 
    //   System.out.println(i + ":" + rand.nextInt());
    
    // System.out.println();
    // System.out.println("= rand2 =");
    // for (int i = 0; i < 5; i++) 
    //   System.out.println(i + ":" + rand2.nextInt());

    //9-28
    // Random rand = new Random();
    // int[] number = new int[100];
    // int[] counter = new int[10];

    // for(int i = 0; i < number.length; i++) {
    //   System.out.print(number[i] = (int)(Math.random() * 10));
    //   System.out.print(number[i] = rand.nextInt(10));
    // }

    // System.out.println();
    // for(int i = 0; i < number.length ; i ++)
    //   counter[number[i]]++;
    // for(int i = 0; i < counter.length; i ++)
    //   System.out.println(i + "의 개수 : "+ printGraph('#',counter[i])+" " + counter[i]);
  // }
  //9-28
  // public static String printGraph(char ch, int value) {
  //   char[] bar = new char[value];
  //   for(int i = 0; i < bar.length; i++)
  //     bar[i] = ch;
  //   return new String(bar);


  //9-29
  //   for(int i = 0; i < 10; i++)
  //     System.out.print(getRand(5,10)+ ",");
  //   System.out.println();

  //   int[] result = fillRand(new int[10], new int[] { 2, 3, 7, 5});

  //   System.out.println(Arrays.toString(result));
  // }
  // public static int[] fillRand(int[] arr, int from, int to) {
  //   for(int i = 0; i < arr.length; i++)
  //     arr[i] = getRand(from, to);
  //   return arr;
  // }
  // public static int[] fillRand(int[] arr, int[] data) {
  //   for(int i = 0; i < arr.length; i++)
  //     arr[i] = data[getRand(0, data.length-1)];
  //   return arr;
  // }
  // public static int getRand(int from, int to) {
  //   return (int) (Math.random() * (Math.abs(to-from)+1)) + Math.min(from, to);


    //9-31
    // String[] data = {"bat", "baby", "bonus", "cA", "ca", "co", "c.", "c0", "car", "combat", "count", "date", "dics"};
    // Pattern p = Pattern.compile("c[a-z]*");
    // for(int i = 0; i < data.length; i++) {
    //   Matcher m = p.matcher(data[i]);
    //   if(m.matches())
    //     System.out.print(data[i] + ",");
    // }


    //9-32
    // String[] data = {"bat", "baby", "bonus", "cA", "ca", "co", "c.", "c0", "car", "combat", "count", "date", "dics"};

    // String[] pattern = {".*", "c[a-z]*", "c[a-z]", "c[a-azA-Z]", "c[a-zA-Z0-9]", "c.", "c.*", "c\\.", "c\\w", "c\\d", "c.*t", "[b|c].*", ".*a.*", ".*a.+", "[b|c].{2}" };

    // for(int x = 0; x < pattern.length; x++) {
    //   Pattern p = Pattern.compile(pattern[x]);
    //   System.out.print("Pattern : " + pattern[x] + " 결과: ");
    //   for(int i = 0; i < data.length; i++) {
    //     Matcher m = p.matcher(data[i]);
    //     if(m.matches())
    //       System.out.print(data[i] + ",");
    //   }
    //   System.out.println();
    // }

    //9-33
    // String source = "HP:011-1111-1111, HOME:02-999-9999";
    // String pattern = "(0\\d{1,2})-(\\d{3,4})-(\\d{4}))";

    // Pattern p = Pattern.compile(pattern);
    // Matcher m = p.matcher(source);

    // int i = 0;
    // while(m.find()) {
    //   System.out.println(++i + ": " + m.group() + " -> " + m.group(1) + ", " + m.group(2) + ", " + m.group(3));
    // }


    //9-34
    // String source = "A broken hand works, but not a broken heart.";
    // String pattern = "broken";
    // StringBuffer sb = new StringBuffer();

    // Pattern p = Pattern.compile(pattern);
    // Matcher m = p.matcher(source);
    // System.out.println("source:" + source);

    // int i = 0;

    // while(m.find()) {
    //   System.out.println(++i + "번째 매칭: " + m.start() + "~" + m.end());
    //   m.appendReplacement(sb, "drunken");
    // }
    // m.appendTail(sb);
    // System.out.println("Replacement count : " + i);
    // System.out.println("result: " + sb.toString());


    //9-35
    Scanner s = new Scanner(System.in);
    String[] argArr = null;

    while(true) {
      String prompt = ">>";
      System.out.print(prompt);

      String input = s.nextLine();

      input = input.trim();
      argArr = input.split(" +");

      String command = argArr[0].trim();

      if("".equals(command)) continue;

      command = command.toLowerCase();

      if(command.equals("q")) {
        System.exit(0);
      } else {
        for(int i = 0; i < argArr.length; i++)
          System.out.println(argArr[i]);
      }
    }
  }
}